import '/components/alert_card/alert_card_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'alertas_widget.dart' show AlertasWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class AlertasModel extends FlutterFlowModel<AlertasWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for AlertCard.
  late AlertCardModel alertCardModel1;
  // Model for AlertCard.
  late AlertCardModel alertCardModel2;
  // Model for AlertCard.
  late AlertCardModel alertCardModel3;
  // Model for AlertCard.
  late AlertCardModel alertCardModel4;

  @override
  void initState(BuildContext context) {
    alertCardModel1 = createModel(context, () => AlertCardModel());
    alertCardModel2 = createModel(context, () => AlertCardModel());
    alertCardModel3 = createModel(context, () => AlertCardModel());
    alertCardModel4 = createModel(context, () => AlertCardModel());
  }

  @override
  void dispose() {
    alertCardModel1.dispose();
    alertCardModel2.dispose();
    alertCardModel3.dispose();
    alertCardModel4.dispose();
  }
}
