import '/components/button/button_widget.dart';
import '/components/hotspot_item/hotspot_item_widget.dart';
import '/components/risk_stat_card/risk_stat_card_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 'home_dashboard_widget.dart' show HomeDashboardWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class HomeDashboardModel extends FlutterFlowModel<HomeDashboardWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for RiskStatCard.
  late RiskStatCardModel riskStatCardModel1;
  // Model for RiskStatCard.
  late RiskStatCardModel riskStatCardModel2;
  // Model for RiskStatCard.
  late RiskStatCardModel riskStatCardModel3;
  // Model for Button.
  late ButtonModel buttonModel1;
  // Model for Button.
  late ButtonModel buttonModel2;
  // Model for Button.
  late ButtonModel buttonModel3;
  // Model for HotspotItem.
  late HotspotItemModel hotspotItemModel1;
  // Model for HotspotItem.
  late HotspotItemModel hotspotItemModel2;
  // Model for HotspotItem.
  late HotspotItemModel hotspotItemModel3;

  @override
  void initState(BuildContext context) {
    riskStatCardModel1 = createModel(context, () => RiskStatCardModel());
    riskStatCardModel2 = createModel(context, () => RiskStatCardModel());
    riskStatCardModel3 = createModel(context, () => RiskStatCardModel());
    buttonModel1 = createModel(context, () => ButtonModel());
    buttonModel2 = createModel(context, () => ButtonModel());
    buttonModel3 = createModel(context, () => ButtonModel());
    hotspotItemModel1 = createModel(context, () => HotspotItemModel());
    hotspotItemModel2 = createModel(context, () => HotspotItemModel());
    hotspotItemModel3 = createModel(context, () => HotspotItemModel());
  }

  @override
  void dispose() {
    riskStatCardModel1.dispose();
    riskStatCardModel2.dispose();
    riskStatCardModel3.dispose();
    buttonModel1.dispose();
    buttonModel2.dispose();
    buttonModel3.dispose();
    hotspotItemModel1.dispose();
    hotspotItemModel2.dispose();
    hotspotItemModel3.dispose();
  }
}
