import '/components/project_section/project_section_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'sobre_o_projeto_widget.dart' show SobreOProjetoWidget;
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class SobreOProjetoModel extends FlutterFlowModel<SobreOProjetoWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for ProjectSection.
  late ProjectSectionModel projectSectionModel1;
  // Model for ProjectSection.
  late ProjectSectionModel projectSectionModel2;
  // Model for ProjectSection.
  late ProjectSectionModel projectSectionModel3;
  // Model for ProjectSection.
  late ProjectSectionModel projectSectionModel4;

  @override
  void initState(BuildContext context) {
    projectSectionModel1 = createModel(context, () => ProjectSectionModel());
    projectSectionModel2 = createModel(context, () => ProjectSectionModel());
    projectSectionModel3 = createModel(context, () => ProjectSectionModel());
    projectSectionModel4 = createModel(context, () => ProjectSectionModel());
  }

  @override
  void dispose() {
    projectSectionModel1.dispose();
    projectSectionModel2.dispose();
    projectSectionModel3.dispose();
    projectSectionModel4.dispose();
  }
}
