import '/components/data_source_card/data_source_card_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 'fontes_de_dados_widget.dart' show FontesDeDadosWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class FontesDeDadosModel extends FlutterFlowModel<FontesDeDadosWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for DataSourceCard.
  late DataSourceCardModel dataSourceCardModel1;
  // Model for DataSourceCard.
  late DataSourceCardModel dataSourceCardModel2;
  // Model for DataSourceCard.
  late DataSourceCardModel dataSourceCardModel3;

  @override
  void initState(BuildContext context) {
    dataSourceCardModel1 = createModel(context, () => DataSourceCardModel());
    dataSourceCardModel2 = createModel(context, () => DataSourceCardModel());
    dataSourceCardModel3 = createModel(context, () => DataSourceCardModel());
  }

  @override
  void dispose() {
    dataSourceCardModel1.dispose();
    dataSourceCardModel2.dispose();
    dataSourceCardModel3.dispose();
  }
}
