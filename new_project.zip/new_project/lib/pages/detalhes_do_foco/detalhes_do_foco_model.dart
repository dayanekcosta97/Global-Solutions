import '/components/button/button_widget.dart';
import '/components/detail_info_row/detail_info_row_widget.dart';
import '/components/recommendation_item/recommendation_item_widget.dart';
import '/components/risk_badge/risk_badge_widget.dart';
import '/flutter_flow/flutter_flow_google_map.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'detalhes_do_foco_widget.dart' show DetalhesDoFocoWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class DetalhesDoFocoModel extends FlutterFlowModel<DetalhesDoFocoWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for Map Google Map widget.
  LatLng? mapGoogleMapsCenter;
  final mapGoogleMapsController = Completer<GoogleMapController>();
  // Model for RiskBadge.
  late RiskBadgeModel riskBadgeModel;
  // Model for DetailInfoRow.
  late DetailInfoRowModel detailInfoRowModel1;
  // Model for DetailInfoRow.
  late DetailInfoRowModel detailInfoRowModel2;
  // Model for DetailInfoRow.
  late DetailInfoRowModel detailInfoRowModel3;
  // Model for DetailInfoRow.
  late DetailInfoRowModel detailInfoRowModel4;
  // Model for DetailInfoRow.
  late DetailInfoRowModel detailInfoRowModel5;
  // Model for DetailInfoRow.
  late DetailInfoRowModel detailInfoRowModel6;
  // Model for RecommendationItem.
  late RecommendationItemModel recommendationItemModel1;
  // Model for RecommendationItem.
  late RecommendationItemModel recommendationItemModel2;
  // Model for RecommendationItem.
  late RecommendationItemModel recommendationItemModel3;
  // Model for RecommendationItem.
  late RecommendationItemModel recommendationItemModel4;
  // Model for Button.
  late ButtonModel buttonModel;

  @override
  void initState(BuildContext context) {
    riskBadgeModel = createModel(context, () => RiskBadgeModel());
    detailInfoRowModel1 = createModel(context, () => DetailInfoRowModel());
    detailInfoRowModel2 = createModel(context, () => DetailInfoRowModel());
    detailInfoRowModel3 = createModel(context, () => DetailInfoRowModel());
    detailInfoRowModel4 = createModel(context, () => DetailInfoRowModel());
    detailInfoRowModel5 = createModel(context, () => DetailInfoRowModel());
    detailInfoRowModel6 = createModel(context, () => DetailInfoRowModel());
    recommendationItemModel1 =
        createModel(context, () => RecommendationItemModel());
    recommendationItemModel2 =
        createModel(context, () => RecommendationItemModel());
    recommendationItemModel3 =
        createModel(context, () => RecommendationItemModel());
    recommendationItemModel4 =
        createModel(context, () => RecommendationItemModel());
    buttonModel = createModel(context, () => ButtonModel());
  }

  @override
  void dispose() {
    riskBadgeModel.dispose();
    detailInfoRowModel1.dispose();
    detailInfoRowModel2.dispose();
    detailInfoRowModel3.dispose();
    detailInfoRowModel4.dispose();
    detailInfoRowModel5.dispose();
    detailInfoRowModel6.dispose();
    recommendationItemModel1.dispose();
    recommendationItemModel2.dispose();
    recommendationItemModel3.dispose();
    recommendationItemModel4.dispose();
    buttonModel.dispose();
  }
}
