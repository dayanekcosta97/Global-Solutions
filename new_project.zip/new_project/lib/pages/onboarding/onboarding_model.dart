import '/components/button/button_widget.dart';
import '/components/onboarding_slide/onboarding_slide_widget.dart';
import '/components/page_indicator/page_indicator_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'onboarding_widget.dart' show OnboardingWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class OnboardingModel extends FlutterFlowModel<OnboardingWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for OnboardingSlide.
  late OnboardingSlideModel onboardingSlideModel;
  // Model for PageIndicator.
  late PageIndicatorModel pageIndicatorModel;
  // Model for Button.
  late ButtonModel buttonModel;

  @override
  void initState(BuildContext context) {
    onboardingSlideModel = createModel(context, () => OnboardingSlideModel());
    pageIndicatorModel = createModel(context, () => PageIndicatorModel());
    buttonModel = createModel(context, () => ButtonModel());
  }

  @override
  void dispose() {
    onboardingSlideModel.dispose();
    pageIndicatorModel.dispose();
    buttonModel.dispose();
  }
}
