import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'detail_info_row_widget.dart' show DetailInfoRowWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class DetailInfoRowModel extends FlutterFlowModel<DetailInfoRowWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
