// Export pages
export '/pages/onboarding/onboarding_widget.dart' show OnboardingWidget;
export '/pages/home_dashboard/home_dashboard_widget.dart'
    show HomeDashboardWidget;
export '/pages/mapa_de_queimadas/mapa_de_queimadas_widget.dart'
    show MapaDeQueimadasWidget;
export '/pages/alertas/alertas_widget.dart' show AlertasWidget;
export '/pages/detalhes_do_foco/detalhes_do_foco_widget.dart'
    show DetalhesDoFocoWidget;
export '/pages/fontes_de_dados/fontes_de_dados_widget.dart'
    show FontesDeDadosWidget;
export '/pages/sobre_o_projeto/sobre_o_projeto_widget.dart'
    show SobreOProjetoWidget;
